Waterflood Optimizer export
run f1f43bbedd07 · data f7fda78b31f7 · config 7f90028e1dc1 · code cbb7eec

Files: run.csv, wells.csv, change_list.csv, connectivity.csv, tau.csv, injector_efficiency.csv, forecast_field.csv, forecast_wells.csv, history_match.csv, leaderboard.csv, gates.csv, conditions.csv, data_quality.csv, workflow.csv, rates.csv
